-- Create database
CREATE DATABASE IF NOT EXISTS atm;
USE atm;

-- Users table
CREATE TABLE users (
    card_number VARCHAR(4) PRIMARY KEY,
    pin VARCHAR(4) NOT NULL,
    name VARCHAR(100) NOT NULL,
    balance DOUBLE DEFAULT 0.0
);

-- Transactions table
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    card_number VARCHAR(4) NOT NULL,
    type ENUM('withdraw', 'deposit', 'balance_check') NOT NULL,
    amount DOUBLE,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (card_number) REFERENCES users(card_number)
);

-- Insert sample data
INSERT INTO users (card_number, pin, name, balance) VALUES
('1234', '1234', 'John Doe', 1000.00),
('5678', '5678', 'Jane Smith', 500.00),
('8055', '8055', 'Alex Brown', 750.00);