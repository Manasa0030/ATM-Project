package atm;

import java.sql.Timestamp;

public class Transaction {
    private int id;
    private String cardNumber;
    private String type;
    private double amount;
    private Timestamp date;

    public Transaction(int id, String cardNumber, String type, double amount, Timestamp date) {
        this.id = id;
        this.cardNumber = cardNumber;
        this.type = type;
        this.amount = amount;
        this.date = date;
    }

    public int getId() { return id; }
    public String getCardNumber() { return cardNumber; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public Timestamp getDate() { return date; }
}