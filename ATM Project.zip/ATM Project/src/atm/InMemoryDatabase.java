package atm;

import java.util.*;

public class InMemoryDatabase {
    private static final Map<String, User> users = new HashMap<>();
    private static final List<Transaction> transactions = new ArrayList<>();

    static {
        // Initialize with sample data
        users.put("1234", new User("1234", "1234", "John Doe", 1000.00));
        users.put("5678", new User("5678", "5678", "Jane Smith", 500.00));
        users.put("8055", new User("8055", "8055", "Alex Brown", 750.00));
    }

    public static User getUser(String accountNumber) {
        return users.get(accountNumber);
    }

    public static void updateBalance(String accountNumber, double newBalance) {
        User user = users.get(accountNumber);
        if (user != null) {
            user.setBalance(newBalance);
        }
    }

    public static void addTransaction(String accountNumber, String type, double amount) {
        transactions.add(new Transaction(transactions.size() + 1, accountNumber, type, amount, new java.sql.Timestamp(System.currentTimeMillis())));
    }

    public static List<Transaction> getTransactions(String accountNumber) {
        List<Transaction> userTransactions = new ArrayList<>();
        for (Transaction t : transactions) {
            if (t.getCardNumber().equals(accountNumber)) {
                userTransactions.add(t);
            }
        }
        return userTransactions;
    }
}