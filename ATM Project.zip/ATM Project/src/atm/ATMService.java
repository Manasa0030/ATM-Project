package atm;

import java.util.ArrayList;
import java.util.List;

public class ATMService {
    private String lastError;

    public String getLastError() {
        return lastError;
    }

    public User authenticate(String accountNumber) {
        User user = InMemoryDatabase.getUser(accountNumber);
        if (user != null) {
            lastError = null;
        } else {
            lastError = "Account not found";
        }
        return user;
    }

    public double getBalance(String cardNumber) {
        User user = InMemoryDatabase.getUser(cardNumber);
        return user != null ? user.getBalance() : 0.0;
    }

    public boolean withdraw(String cardNumber, double amount) {
        double balance = getBalance(cardNumber);
        if (balance >= amount) {
            InMemoryDatabase.updateBalance(cardNumber, balance - amount);
            InMemoryDatabase.addTransaction(cardNumber, "withdraw", amount);
            return true;
        }
        return false;
    }

    public boolean deposit(String cardNumber, double amount) {
        double balance = getBalance(cardNumber);
        InMemoryDatabase.updateBalance(cardNumber, balance + amount);
        InMemoryDatabase.addTransaction(cardNumber, "deposit", amount);
        return true;
    }

    public boolean changePin(String cardNumber, String newPin) {
        User user = InMemoryDatabase.getUser(cardNumber);
        if (user != null) {
            user.setPin(newPin);
            return true;
        }
        return false;
    }

    public List<Transaction> getTransactions(String cardNumber) {
        return InMemoryDatabase.getTransactions(cardNumber);
    }
}