package atm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ATMGUI extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private ATMService service;
    private User currentUser;
    private LoginPanel loginPanel;
    private MenuPanel menuPanel;
    private WithdrawPanel withdrawPanel;
    private DepositPanel depositPanel;
    private BalancePanel balancePanel;
    private ChangePinPanel changePinPanel;
    private TransactionHistoryPanel historyPanel;

    public ATMGUI() {
        service = new ATMService();
        initializeComponents();
        setTitle("ATM Machine");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initializeComponents() {
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        loginPanel = new LoginPanel();
        menuPanel = new MenuPanel();
        withdrawPanel = new WithdrawPanel();
        depositPanel = new DepositPanel();
        balancePanel = new BalancePanel();
        changePinPanel = new ChangePinPanel();
        historyPanel = new TransactionHistoryPanel();
        mainPanel.add(loginPanel, "Login");
        mainPanel.add(menuPanel, "Menu");
        mainPanel.add(withdrawPanel, "Withdraw");
        mainPanel.add(depositPanel, "Deposit");
        mainPanel.add(balancePanel, "Balance");
        mainPanel.add(changePinPanel, "ChangePin");
        mainPanel.add(historyPanel, "History");
        add(mainPanel);
        cardLayout.show(mainPanel, "Login");
    }

    private void showPanel(String name) {
        cardLayout.show(mainPanel, name);
    }

    private class LoginPanel extends JPanel {
        private JTextField accountField;
        private JButton loginButton;

        public LoginPanel() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            
            JLabel titleLabel = new JLabel("ATM Machine Login");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            add(titleLabel, gbc);
            
            JLabel accountLabel = new JLabel("Account Number:");
            accountLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            add(accountLabel, gbc);
            
            accountField = new JTextField(15);
            accountField.setFont(new Font("Arial", Font.PLAIN, 18));
            gbc.gridx = 1;
            gbc.gridy = 1;
            add(accountField, gbc);
            
            loginButton = new JButton("Continue");
            loginButton.setFont(new Font("Arial", Font.BOLD, 18));
            loginButton.setPreferredSize(new Dimension(150, 50));
            loginButton.addActionListener(e -> login());
            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 2;
            add(loginButton, gbc);
        }

        private void login() {
            String accNo = accountField.getText();
            currentUser = service.authenticate(accNo);
            if (currentUser != null) {
                showPanel("Menu");
                accountField.setText("");
            } else {
                String error = service.getLastError();
                if (error != null) {
                    JOptionPane.showMessageDialog(this, "Database error: " + error);
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid account number");
                }
            }
        }
    }

    private class MenuPanel extends JPanel {
        public MenuPanel() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(15, 15, 15, 15);
            
            JLabel titleLabel = new JLabel("ATM Main Menu");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            add(titleLabel, gbc);
            
            JLabel userLabel = new JLabel("Welcome!");
            userLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 2;
            add(userLabel, gbc);
            
            JButton withdrawBtn = new JButton("Withdraw");
            withdrawBtn.setFont(new Font("Arial", Font.BOLD, 18));
            withdrawBtn.setPreferredSize(new Dimension(200, 60));
            withdrawBtn.addActionListener(e -> showPanel("Withdraw"));
            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            add(withdrawBtn, gbc);
            
            JButton depositBtn = new JButton("Deposit");
            depositBtn.setFont(new Font("Arial", Font.BOLD, 18));
            depositBtn.setPreferredSize(new Dimension(200, 60));
            depositBtn.addActionListener(e -> showPanel("Deposit"));
            gbc.gridx = 1;
            gbc.gridy = 2;
            add(depositBtn, gbc);
            
            JButton balanceBtn = new JButton("Check Balance");
            balanceBtn.setFont(new Font("Arial", Font.BOLD, 18));
            balanceBtn.setPreferredSize(new Dimension(200, 60));
            balanceBtn.addActionListener(e -> {
                balancePanel.updateBalance();
                showPanel("Balance");
            });
            gbc.gridx = 0;
            gbc.gridy = 3;
            add(balanceBtn, gbc);
            
            JButton logoutBtn = new JButton("Logout");
            logoutBtn.setFont(new Font("Arial", Font.BOLD, 18));
            logoutBtn.setPreferredSize(new Dimension(200, 60));
            logoutBtn.addActionListener(e -> {
                currentUser = null;
                showPanel("Login");
            });
            gbc.gridx = 1;
            gbc.gridy = 3;
            add(logoutBtn, gbc);
        }
    }

    private class WithdrawPanel extends JPanel {
        private JTextField amountField;
        private JButton withdrawBtn;
        private JButton backBtn;

        public WithdrawPanel() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(15, 15, 15, 15);
            
            JLabel titleLabel = new JLabel("Withdraw Amount");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            add(titleLabel, gbc);
            
            JLabel amountLabel = new JLabel("Enter amount:");
            amountLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            add(amountLabel, gbc);
            
            amountField = new JTextField(15);
            amountField.setFont(new Font("Arial", Font.PLAIN, 18));
            gbc.gridx = 1;
            gbc.gridy = 1;
            add(amountField, gbc);
            
            withdrawBtn = new JButton("Withdraw");
            withdrawBtn.setFont(new Font("Arial", Font.BOLD, 18));
            withdrawBtn.setPreferredSize(new Dimension(150, 50));
            withdrawBtn.addActionListener(e -> withdraw());
            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            add(withdrawBtn, gbc);
            
            backBtn = new JButton("Back");
            backBtn.setFont(new Font("Arial", Font.BOLD, 18));
            backBtn.setPreferredSize(new Dimension(150, 50));
            backBtn.addActionListener(e -> {
                amountField.setText("");
                showPanel("Menu");
            });
            gbc.gridx = 1;
            gbc.gridy = 2;
            add(backBtn, gbc);
        }

        private void withdraw() {
            try {
                double amount = Double.parseDouble(amountField.getText());
                if (amount <= 0) {
                    JOptionPane.showMessageDialog(this, "Amount must be greater than 0");
                    return;
                }
                if (service.withdraw(currentUser.getCardNumber(), amount)) {
                    JOptionPane.showMessageDialog(this, "Withdrawal successful!\nAmount: $" + amount);
                    amountField.setText("");
                    showPanel("Menu");
                } else {
                    JOptionPane.showMessageDialog(this, "Insufficient balance");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid amount");
            }
        }
    }

    private class DepositPanel extends JPanel {
        private JTextField amountField;
        private JButton depositBtn;
        private JButton backBtn;

        public DepositPanel() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(15, 15, 15, 15);
            
            JLabel titleLabel = new JLabel("Deposit Amount");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            add(titleLabel, gbc);
            
            JLabel amountLabel = new JLabel("Enter amount:");
            amountLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            add(amountLabel, gbc);
            
            amountField = new JTextField(15);
            amountField.setFont(new Font("Arial", Font.PLAIN, 18));
            gbc.gridx = 1;
            gbc.gridy = 1;
            add(amountField, gbc);
            
            depositBtn = new JButton("Deposit");
            depositBtn.setFont(new Font("Arial", Font.BOLD, 18));
            depositBtn.setPreferredSize(new Dimension(150, 50));
            depositBtn.addActionListener(e -> deposit());
            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            add(depositBtn, gbc);
            
            backBtn = new JButton("Back");
            backBtn.setFont(new Font("Arial", Font.BOLD, 18));
            backBtn.setPreferredSize(new Dimension(150, 50));
            backBtn.addActionListener(e -> {
                amountField.setText("");
                showPanel("Menu");
            });
            gbc.gridx = 1;
            gbc.gridy = 2;
            add(backBtn, gbc);
        }

        private void deposit() {
            try {
                double amount = Double.parseDouble(amountField.getText());
                if (amount <= 0) {
                    JOptionPane.showMessageDialog(this, "Amount must be greater than 0");
                    return;
                }
                if (service.deposit(currentUser.getCardNumber(), amount)) {
                    JOptionPane.showMessageDialog(this, "Deposit successful!\nAmount: $" + amount);
                    amountField.setText("");
                    showPanel("Menu");
                } else {
                    JOptionPane.showMessageDialog(this, "Deposit failed");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid amount");
            }
        }
    }

    private class BalancePanel extends JPanel {
        private JLabel balanceLabel;
        private JButton backBtn;

        public BalancePanel() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(15, 15, 15, 15);
            
            JLabel titleLabel = new JLabel("Account Balance");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
            gbc.gridx = 0;
            gbc.gridy = 0;
            add(titleLabel, gbc);
            
            balanceLabel = new JLabel("$0.00");
            balanceLabel.setFont(new Font("Arial", Font.BOLD, 48));
            gbc.gridx = 0;
            gbc.gridy = 1;
            add(balanceLabel, gbc);
            
            backBtn = new JButton("Back");
            backBtn.setFont(new Font("Arial", Font.BOLD, 18));
            backBtn.setPreferredSize(new Dimension(150, 50));
            backBtn.addActionListener(e -> showPanel("Menu"));
            gbc.gridx = 0;
            gbc.gridy = 2;
            add(backBtn, gbc);
        }

        public void updateBalance() {
            double balance = service.getBalance(currentUser.getCardNumber());
            balanceLabel.setText("$" + String.format("%.2f", balance));
        }
    }

    private class ChangePinPanel extends JPanel {
        private JPasswordField newPinField;
        private JPasswordField confirmPinField;
        private JButton changeBtn;
        private JButton backBtn;

        public ChangePinPanel() {
            setLayout(new GridLayout(3, 2));
            add(new JLabel("New PIN:"));
            newPinField = new JPasswordField();
            add(newPinField);
            add(new JLabel("Confirm PIN:"));
            confirmPinField = new JPasswordField();
            add(confirmPinField);
            changeBtn = new JButton("Change");
            changeBtn.addActionListener(e -> changePin());
            add(changeBtn);
            backBtn = new JButton("Back");
            backBtn.addActionListener(e -> showPanel("Menu"));
            add(backBtn);
        }

        private void changePin() {
            String newPin = new String(newPinField.getPassword());
            String confirmPin = new String(confirmPinField.getPassword());
            if (newPin.equals(confirmPin) && newPin.length() == 4) {
                if (service.changePin(currentUser.getCardNumber(), newPin)) {
                    JOptionPane.showMessageDialog(this, "PIN changed successfully");
                    newPinField.setText("");
                    confirmPinField.setText("");
                    showPanel("Menu");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to change PIN");
                }
            } else {
                JOptionPane.showMessageDialog(this, "PINs do not match or invalid length");
            }
        }
    }

    private class TransactionHistoryPanel extends JPanel {
        private JTextArea historyArea;
        private JButton backBtn;

        public TransactionHistoryPanel() {
            setLayout(new BorderLayout());
            historyArea = new JTextArea();
            historyArea.setEditable(false);
            add(new JScrollPane(historyArea), BorderLayout.CENTER);
            backBtn = new JButton("Back");
            backBtn.addActionListener(e -> showPanel("Menu"));
            add(backBtn, BorderLayout.SOUTH);
        }

        public void updateHistory() {
            List<Transaction> transactions = service.getTransactions(currentUser.getCardNumber());
            StringBuilder sb = new StringBuilder();
            for (Transaction t : transactions) {
                sb.append(t.getDate()).append(" - ").append(t.getType()).append(" - $").append(t.getAmount()).append("\n");
            }
            historyArea.setText(sb.toString());
        }
    }
}