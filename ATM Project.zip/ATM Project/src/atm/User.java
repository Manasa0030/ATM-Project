package atm;

public class User {
    private String cardNumber;
    private String pin;
    private String name;
    private double balance;

    public User(String cardNumber, String pin, String name, double balance) {
        this.cardNumber = cardNumber;
        this.pin = pin;
        this.name = name;
        this.balance = balance;
    }

    public String getCardNumber() { return cardNumber; }
    public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }
    public String getPin() { return pin; }
    public void setPin(String pin) { this.pin = pin; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
}